#!/bin/bash
wget -O ./models/convert_caffemodel/params/vgg_params.npz http://www.eecs.berkeley.edu/~ronghang/projects/text_objseg/models/vgg_params.npz
